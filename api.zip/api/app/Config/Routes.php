<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes-->resource('productos', ['controller' => 'ProductoController']);
$routes->get('productos/(:num)', 'ProductController::show/$1');
$routes->post('productos', 'ProductController::create');
$routes->put('productos/(:num)', 'ProductController::update/$1');
$routes->delete('productos/(:num)', 'ProductController::delete/$1');
