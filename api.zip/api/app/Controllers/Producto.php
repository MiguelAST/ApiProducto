<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Producto extends BaseController
{
    public function index()
    {
        $products = $this->productModel->orderBy('id', 'asc')->findAll();
        $data = ['productos' => $productos
    ];
        return $this->respond($data);
    }

    public function show($id = null)
    {
        $product = $this->productModel->find($id);
        if ($product) {
            return $this->respond($product);
        } else {
            return $this->failNotFound('Producto no encontrado');
        }
    }

    public function create()
    {

    $data = $this->request->getJSON();
    $this->productModel->insert($data);
    return $this->respondCreated('Producto creado exitosamente');
    
    }

    public function update($id)
    {
    // Actualizar un producto por su ID
    $data = $this->request->getJSON();
    if ($this->productModel->update($id, $data)) {
        return $this->respond('Producto actualizado exitosamente');
    } else {
        return $this->failNotFound('Producto no encontrado');
    }
    }

    public function delete($id)
    {
     // Eliminar un producto por su ID
     if ($this->productModel->delete($id)) {
        return $this->respond('Producto eliminado exitosamente');
    } else {
        return $this->failNotFound('Producto no encontrado');
    }
    }

}
